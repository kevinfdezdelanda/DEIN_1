module examenEj1 {
	requires java.desktop;
	requires java.sql;
}