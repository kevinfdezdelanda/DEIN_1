package model;

public class AeropuertoPrivado {
	public int idAeropuerto;
	public int nSocios;

	public AeropuertoPrivado() {
	}

	public int getIdAeropuerto() {
		return idAeropuerto;
	}

	public void setIdAeropuerto(int idAeropuerto) {
		this.idAeropuerto = idAeropuerto;
	}

	public int getnSocios() {
		return nSocios;
	}

	public void setnSocios(int nSocios) {
		this.nSocios = nSocios;
	}
	
	
}